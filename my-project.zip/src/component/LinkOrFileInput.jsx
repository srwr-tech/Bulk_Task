import React, { useState, useEffect } from "react";
import "./style.css";
import AddTaskModal from './AddTaskModal'
const LinkOrFileInput = () => {
  const [link, setLink] = useState("");
  const [file, setFile] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false); 
  
  // Fetch tasks from backend
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/tasks");
        const data = await response.json();
        setTasks(data);
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };

    fetchTasks();
  }, []);

  const handleLinkChange = (e) => {
    setLink(e.target.value);
    if (e.target.value) setFile(null);
  };

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      if (selectedFile.type !== "text/csv") {
        alert("Only CSV files are allowed.");
        return;
      }
      setFile(selectedFile);
      setLink("");
    }
  };

  const importTasks = async () => {
    if (link) {
      if (!link.includes("docs.google.com/spreadsheets")) {
        alert("Please enter a valid Google Sheets public link.");
        return;
      }
      try {
        const sheetId = link.split("/d/")[1]?.split("/")[0];
        const response = await fetch(
          `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv`
        );
        const data = await response.text();
        processCSVData(data);
      } catch (error) {
        console.error("Error fetching Google Sheets data:", error);
        alert("Failed to fetch tasks from Google Sheets.");
      }
    } else if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        processCSVData(event.target.result);
      };
      reader.readAsText(file);
    } else {
      alert("Please provide a link or upload a file.");
    }
  };

  const processCSVData = (csvData) => {
    const rows = csvData.split("\n").map(row => row.split(","));
    const formattedTasks = rows.slice(1).map(row => ({
      taskName: row[0] || "N/A",
      description: row[1] || "N/A",
      dueDate: row[2] || "N/A",
      priority: row[3] || "N/A"
    }));
    setTasks(formattedTasks);
    sendDataToBackend(formattedTasks);
  };

  const sendDataToBackend = async (tasks) => {
    try {
      const response = await fetch("http://localhost:5000/api/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tasks })
      });
      if (!response.ok) throw new Error("Failed to save tasks");
      alert("Tasks successfully saved!");
    } catch (error) {
      console.error("Error saving tasks:", error);
      alert("Error saving tasks to backend.");
    }
  };

  // const columns = [
  //   { name: "Task Name", selector: row => row.taskName, sortable: true },
  //   { name: "Description", selector: row => row.description, sortable: true },
  //   { name: "Due Date", selector: row => row.dueDate, sortable: true },
  //   { name: "Priority", selector: row => row.priority, sortable: true }
  // ];

  return (
    <div className="container">
      <div className="box">
      <div>
      <button onClick={() => setIsModalOpen(true)}>Open Modal</button>
      <AddTaskModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />

          </div>
        <h2>Upload File or Paste Google Sheets Link</h2>
        {!file && (
          <input
            type="text"
            placeholder="Paste your Google Sheets public link here"
            value={link}
            onChange={handleLinkChange}
            className="input-field"
          />
        )}
        {!link && (
          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            className="file-input"
          />
        )}
        <button onClick={importTasks} className="import-button">Import Tasks</button>
        {link && <p className="message success">✔ Link added</p>}
        {file && <p className="message info">✔ File selected: {file.name}</p>}
        
      </div>
     
    </div>
  );
};

export default LinkOrFileInput;
