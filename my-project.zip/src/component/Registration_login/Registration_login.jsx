
// import React, { useState } from "react";

// const AuthForm = () => {
//   const [isActive, setIsActive] = useState(false);
//   const [formData, setFormData] = useState({
//     username: "",
//     email: "",
//     password: "",
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   // API call for Signup
//   const handleSignup = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch("http://localhost:5000/auth/signup", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           username: formData.username,
//           email: formData.email,
//           password: formData.password,
//         }),
//       });

//       const data = await response.json();
//       if (response.ok) {
//         alert("Signup Successful!");
//         setIsActive(false); // Switch to login form
//       } else {
//         alert(data.message || "Signup Failed!");
//       }
//     } catch (error) {
//       console.error("Signup Error:", error);
//     }
//   };

//   // API call for Login
//   const handleLogin = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await fetch("http://localhost:5000/auth/signin", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           username: formData.username,
//           password: formData.password,
//         }),
//       });

//       const data = await response.json();
//       if (response.ok) {
//         alert("Login Successful!");
//         console.log("User Data:", data);
//       } else {
//         alert(data.message || "Login Failed!");
//       }
//     } catch (error) {
//       console.error("Login Error:", error);
//     }
//   };

//   return (
//     <div className={`container ${isActive ? "active" : ""}`}>
//       {/* Login Form */}
//       <div className="form-box login">
//         <form onSubmit={handleLogin}>
//           <h1>Login</h1>
//           <div className="input-box">
//             <input
//               type="text"
//               name="username"
//               placeholder="Username"
//               required
//               value={formData.username}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="input-box">
//             <input
//               type="password"
//               name="password"
//               placeholder="Password"
//               required
//               value={formData.password}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="forgot-link">
//             <a href="#">Forgot Password?</a>
//           </div>
//           <button type="submit" className="btn">
//             Login
//           </button>
//         </form>
//       </div>

//       {/* Registration Form */}
//       <div className="form-box register">
//         <form onSubmit={handleSignup}>
//           <h1>Registration</h1>
//           <div className="input-box">
//             <input
//               type="text"
//               name="username"
//               placeholder="Username"
//               required
//               value={formData.username}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="input-box">
//             <input
//               type="email"
//               name="email"
//               placeholder="Email"
//               required
//               value={formData.email}
//               onChange={handleChange}
//             />
//           </div>
//           <div className="input-box">
//             <input
//               type="password"
//               name="password"
//               placeholder="Password"
//               required
//               value={formData.password}
//               onChange={handleChange}
//             />
//           </div>
//           <button type="submit" className="btn">
//             Register
//           </button>
//         </form>
//       </div>

//       {/* Toggle Panel */}
//       <div className="toggle-box">
//         <div className="toggle-panel toggle-left">
//           <h1>Hello, Welcome!</h1>
//           <p>Don't have an account?</p>
//           <button className="btn" onClick={() => setIsActive(true)}>
//             Register
//           </button>
//         </div>

//         <div className="toggle-panel toggle-right">
//           <h1>Welcome Back!</h1>
//           <p>Already have an account?</p>
//           <button className="btn" onClick={() => setIsActive(false)}>
//             Login
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AuthForm;

import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // For redirection
// import LinkOrFileInput from "../LinkOrFileInput";
// import TableComponent from "./TableComponent";

const AuthForm = () => {
  const [isActive, setIsActive] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const navigate = useNavigate(); // Hook for navigation

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Signup API Call
  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (response.ok) {
        alert("Signup Successful!");
        setIsActive(false); // Switch to login form
      } else {
        alert(data.message || "Signup Failed!");
      }
    } catch (error) {
      alert("Signup Error: " + error.message);
    }
  };

  // Login API Call
  const handleLogin = async (e) => {
    console.log(" function called")
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5000/auth/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: formData.username,
          password: formData.password,
        }),
      });

      const data = await response.json();
      console.log(response)
      if (response.ok) {
        localStorage.setItem("token", data.token); // Store token
        alert("Login Successful!");
        navigate("/dashboard"); // Redirect after login
      } else {
        alert(data.message || "Invalid Username or Password!");
      }
    } catch (error) {
      alert("Login Error: " + error.message);
    }
  };

  return (
    <div className={`container ${isActive ? "active" : ""}`}>
      {/* Login Form */}
      <div className="form-box login">
        <form onSubmit={handleLogin}>
          <h1>Login</h1>
          <div className="input-box">
            <input
              type="text"
              name="username"
              placeholder="Username"
              required
              value={formData.username}
              onChange={handleChange}
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              name="password"
              placeholder="Password"
              required
              value={formData.password}
              onChange={handleChange}
            />
          </div>
          <div className="forgot-link">
            <a href="#">Forgot Password?</a>
          </div>
          <button type="submit" className="btn">
            Login
          </button>
        </form>
      </div>

      {/* Registration Form */}
      <div className="form-box register">
        <form onSubmit={handleSignup}>
          <h1>Registration</h1>
          <div className="input-box">
            <input
              type="text"
              name="username"
              placeholder="Username"
              required
              value={formData.username}
              onChange={handleChange}
            />
          </div>
          <div className="input-box">
            <input
              type="email"
              name="email"
              placeholder="Email"
              required
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              name="password"
              placeholder="Password"
              required
              value={formData.password}
              onChange={handleChange}
            />
          </div>
          <button type="submit" className="btn">
            Register
          </button>
        </form>
      </div>

      {/* Toggle Panel */}
      <div className="toggle-box">
        <div className="toggle-panel toggle-left">
          <h1>Hello, Welcome!</h1>
          <p>Don't have an account?</p>
          <button className="btn" onClick={() => setIsActive(true)}>
            Register
          </button>
        </div>

        <div className="toggle-panel toggle-right">
          <h1>Welcome Back!</h1>
          <p>Already have an account?</p>
          <button className="btn" onClick={() => setIsActive(false)}>
            Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;

